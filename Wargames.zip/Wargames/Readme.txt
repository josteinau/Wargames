Github:
https://github.com/josteinau/Wargames
Gitlab:
https://gitlab.stud.idi.ntnu.no/josteiau/Wargames


Programmet mangler akkurat nå gui og unit-tester. Dette skal implementeres før endelig innlevering 23.mai.
Flere metoder skal også implementeres da samt manglende ting i pom.xml og diagrammer.

Filer som units skrives til:
Orcs.csv
deadOrcs.csv
Humans.csv
deadHumans.csv
